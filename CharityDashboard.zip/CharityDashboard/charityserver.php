<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "charity";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
if (isset($_POST['reg_p2'])) {

 
// receive all input values from the form
$charity_name        = mysqli_real_escape_string($conn,$_POST['charity_name']);
$email               = mysqli_real_escape_string($conn,$_POST['email']);
$phone               = mysqli_real_escape_string($conn,$_POST['phone']);
$country             = mysqli_real_escape_string($conn,$_POST['country']);
$campaigns           = mysqli_real_escape_string($conn,$_POST['campaigns']);

// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}

// $sql = "INSERT INTO charity_info (charity_name,email,phone,country,campaigns) VALUES ('charity_name','email','phone','country','campaigns')";



$sql = "INSERT INTO charity_info (charity_name,email,phone,country,campaigns)
VALUES ('$charity_name', '$email', '$phone','$country','$campaigns')";

if(mysqli_query($conn, $sql)){
    // Obtain last inserted id
    $last_id = mysqli_insert_id($conn);




if ($conn->query($sql) === TRUE) {
echo ('New Charity created successfully');
} else {
echo "Error: " . $sql . "<br>" . $conn->error;
}
}
}
$conn->close();
?>