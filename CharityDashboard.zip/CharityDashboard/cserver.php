<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "charity";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
if (isset($_POST['reg_p'])) {
// receive all input values from the form
$campaign_name        = mysqli_real_escape_string($conn,$_POST['campaign_name']);
$select_category      = mysqli_real_escape_string($conn,$_POST['select_category']);
$hosted_by            = mysqli_real_escape_string($conn,$_POST['hosted_by']);
$campaign_description = mysqli_real_escape_string($conn,$_POST['campaign_description']);
$campaign_video_link  = mysqli_real_escape_string($conn,$_POST['campaign_video_link']);
$end_date             = mysqli_real_escape_string($conn,$_POST['end_date']);
$goal                 = mysqli_real_escape_string($conn,$_POST['goal']);
$preloaded_amount     = mysqli_real_escape_string($conn,$_POST['preloaded_amount']);
$close_campaign       = mysqli_real_escape_string($conn,$_POST['close_campaign']);
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$sql = "INSERT INTO create_campaign (campaign_name,select_category,hosted_by,campaign_description,campaign_video_link,end_date,goal,preloaded_amount,close_campaign)
VALUES ('$campaign_name', '$select_category', '$hosted_by','$campaign_description','$campaign_video_link','$end_date','$goal','$preloaded_amount','$close_campaign')";
if(mysqli_query($conn,$sql))
{  
$last_id=mysqli_insert_id($conn);
echo $last_id;
} else {
echo "Error: " . $sql . "<br>" . $conn->error;
}
}
$conn->close();
?>